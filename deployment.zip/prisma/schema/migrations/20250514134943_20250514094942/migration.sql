-- AlterTable
ALTER TABLE "Account" ADD COLUMN     "isPrimary" BOOLEAN NOT NULL DEFAULT false;
