-- AlterTable
ALTER TABLE "Transaction" ADD COLUMN     "transferGroupId" TEXT;
