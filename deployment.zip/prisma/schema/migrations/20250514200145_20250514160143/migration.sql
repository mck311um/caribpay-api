-- AlterTable
ALTER TABLE "Transaction" ADD COLUMN     "reference" TEXT;
